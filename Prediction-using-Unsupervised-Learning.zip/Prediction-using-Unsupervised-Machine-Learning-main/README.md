# Prediction-using-Supervised-Machine-Learning
THE SPARK FOUNDATION TASK-2
